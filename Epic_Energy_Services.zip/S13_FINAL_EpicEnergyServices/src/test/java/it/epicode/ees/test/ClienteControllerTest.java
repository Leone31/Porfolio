package it.epicode.ees.test;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import it.epicode.ees.dto.ClienteDTO;
import it.epicode.ees.dto.IndirizzoDTO;
import it.epicode.ees.impl.LoginRequest;
import it.epicode.ees.model.Indirizzo;
import it.epicode.ees.model.TipoCliente;
import lombok.extern.slf4j.Slf4j;


/**
 * Classe di test per le chiamate del controller cliente
 * @author Marco Gambino
 * 
 */

@Slf4j
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ClienteControllerTest {

	@Autowired TestRestTemplate restTemplate;
	@LocalServerPort int port;

	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("marco31");
		login.setPassword("marco31");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
		String jwt = restTemplate.postForObject(url, loginRequest, String.class);
		log.info("---------" + jwt);
		return jwt;
	}

	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("billiballo");
		login.setPassword("marco31");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
		String jwt = restTemplate.postForObject(url, loginRequest, String.class);
		return jwt;
	}

	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		log.info(jwt);
		return header;
	}

	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}

	@Test
	void inserisciTest() {
		String url = "http://localhost:" + port + "/cliente"; 
		ClienteDTO cdto = new ClienteDTO();
		List<Integer> idI = new ArrayList<Integer>();
		idI.add(1);
		cdto.setPIva("122112");
		cdto.setRagioneSociale("La Bamba");
		cdto.setEmail("labamba@legal.com");
		cdto.setDataInserimento(LocalDate.now());
		cdto.setDataUltimoContatto(LocalDate.of(2022, 05, 01));
		cdto.setFatturatoAnnuale(BigDecimal.valueOf(2000.0));
		cdto.setPec("labamba@pec.it");
		cdto.setTelefono("0912345678");
		cdto.setEmailContatto("mariagiovanna@hotlegal.com");
		cdto.setNomeContatto("Maria");
		cdto.setCognomeContatto("Giovanna");
		cdto.setTelefonoContatto("3283456789");
		cdto.setTipoCliente(TipoCliente.SRL);
		cdto.setIdIndirizzo(idI);

		HttpEntity<ClienteDTO> clienteEntity = new HttpEntity<ClienteDTO>(cdto);
		log.info("----------------inserisciTest" + url + "------POST");
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.POST, clienteEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<ClienteDTO> adminEntity = new HttpEntity<ClienteDTO>(cdto, getAdminHeader());
		log.info("----------------inserisciTest" + url + "------POST");
		r = restTemplate.exchange(url, HttpMethod.POST, adminEntity, String.class);
		log.info(r.toString());
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<ClienteDTO> userEntity = new HttpEntity<ClienteDTO>(cdto, getUserHeader());
		log.info("----------------inserisciTest" + url + "------POST");
		r = restTemplate.exchange(url, HttpMethod.POST,userEntity , String.class);
		log.info(r.toString());
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}

	@Test
	void modificaTest() {
		String url = "http://localhost:" + port + "/cliente/123456789"; 
		ClienteDTO cdto = new ClienteDTO();
		List<Integer> idI = new ArrayList<Integer>();
		idI.add(1);
		cdto.setPIva("123456789");
		cdto.setRagioneSociale("La Bomba");
		cdto.setEmail("labombo@legal.com");
		cdto.setDataInserimento(LocalDate.now());
		cdto.setDataUltimoContatto(LocalDate.of(2022, 05, 01));
		cdto.setFatturatoAnnuale(BigDecimal.valueOf(1256.0));
		cdto.setPec("labombo@pec.it");
		cdto.setTelefono("0911111111");
		cdto.setEmailContatto("billiballo@hotlegal.com");
		cdto.setNomeContatto("Billi");
		cdto.setCognomeContatto("Ballo");
		cdto.setTelefonoContatto("32822223333");
		cdto.setTipoCliente(TipoCliente.SRL);
		cdto.setIdIndirizzo(idI);

		HttpEntity<ClienteDTO> clienteEntity = new HttpEntity<ClienteDTO>(cdto);
		log.info("----------------modificaTest" + url + "------PUT");
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.PUT, clienteEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<ClienteDTO> adminEntity = new HttpEntity<ClienteDTO>(cdto, getAdminHeader());
		log.info("----------------modificaTest" + url + "------PUT");
		r = restTemplate.exchange(url, HttpMethod.PUT, adminEntity, String.class);
		log.info(r.toString());
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<ClienteDTO> userEntity = new HttpEntity<ClienteDTO>(cdto, getUserHeader());
		log.info("----------------modificaTest" + url + "------PUT");
		r = restTemplate.exchange(url, HttpMethod.PUT,userEntity , String.class);
		log.info(r.toString());
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);		
	}

	@Test
	void eliminaTest() {
		String url = "http://localhost:" + port + "/cliente/123456789"; 

		log.info("----------------cancellaTest" + url + "------DELETE");
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		log.info("----------------cancellaTest" + url + "------DELETE");
		r = restTemplate.exchange(url, HttpMethod.DELETE, adminEntity, String.class);
		log.info(r.toString());
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		log.info("----------------cancellaTest" + url + "------DELETE");
		r = restTemplate.exchange(url, HttpMethod.DELETE,userEntity , String.class);
		log.info(r.toString());
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);		
	}


	@Test
	void trovaTuttiPaged() {
		String url = "http://localhost:" + port + "/cliente/trovatuttipaginati" ;
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}

	@Test
	void cercaPerNomePaged() {
		String url = "http://localhost:" + port + "/cliente/cercapernome/bianca";
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}

	@Test
	void cercaPerDataInserimento() {
		String url = "http://localhost:" + port + "/cliente/data/2022-05-26"; 
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}

	@Test
	void cercaPerFatturatoAnnuale() {
		String url = "http://localhost:" + port + "/cliente/fatturatoannuale/2000.0";
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("=============TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}

	@Test
	void cercaPerDataUltimoContatto() {
		String url = "http://localhost:" + port + "/cliente/ultimocontatto/2022-08-16";
		ResponseEntity<String> r = restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = restTemplate.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}












}
