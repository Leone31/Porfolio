package it.epicode.ees.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.ees.dto.ClienteDTO;
import it.epicode.ees.dto.ComuneDTO;
import it.epicode.ees.dto.IndirizzoDTO;
import it.epicode.ees.dto.StatoFatturaDTO;
import it.epicode.ees.impl.LoginRequest;
import it.epicode.ees.model.TipoIndirizzo;
import lombok.extern.slf4j.Slf4j;

/**
 * Classe di test per le chiamate del controller comune
 * @author Marco Gambino
 * 
 */

@Slf4j
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ComuneTest {

	@Autowired TestRestTemplate trt;
	@LocalServerPort int port;
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("marco31");
		login.setPassword("marco31");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
		String jwt = trt.postForObject(url, loginRequest, String.class);
		log.info("---------" + jwt);
		return jwt;
	}
	
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("billiballo");
		login.setPassword("marco31");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		log.info(jwt);
		return header;
	}
	
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	@Test
	void inserisciTest() {
		String url = "http://localhost:" + port + "/comune"; 
		ComuneDTO cdto = new ComuneDTO();
		cdto.setCap("90100");
		cdto.setNome("Dixit");
		cdto.setId_provincia("PA");
		
		HttpEntity<ComuneDTO> entity = new HttpEntity<ComuneDTO>(cdto);
		log.info("----------------inserisciTest" + url + "------POST");
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.POST, entity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<ComuneDTO> adminEntity = new HttpEntity<ComuneDTO>(cdto, getAdminHeader());
		log.info("----------------inserisciTest" + url + "------POST");
		r = trt.exchange(url, HttpMethod.POST, adminEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<ComuneDTO> userEntity = new HttpEntity<ComuneDTO>(cdto, getUserHeader());
		log.info("----------------inserisciTest" + url + "------POST");
		r = trt.exchange(url, HttpMethod.POST,userEntity , String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);		
	}
	
	@Test
	void modificaTest() {
		String url = "http://localhost:" + port + "/comune/1"; 
		ComuneDTO cdto = new ComuneDTO();
		cdto.setCap("90100");
		cdto.setNome("Agraba");
		cdto.setId_provincia("PA");
		
		HttpEntity<ComuneDTO> entity = new HttpEntity<ComuneDTO>(cdto);
		log.info("----------------modificaTest" + url + "------PUT");
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.PUT, entity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<ComuneDTO> adminEntity = new HttpEntity<ComuneDTO>(cdto, getAdminHeader());
		log.info("----------------modificaTest" + url + "------PUT");
		r = trt.exchange(url, HttpMethod.PUT, adminEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<ComuneDTO> userEntity = new HttpEntity<ComuneDTO>(cdto, getUserHeader());
		log.info("----------------modificaTest" + url + "------PUT");
		r = trt.exchange(url, HttpMethod.PUT,userEntity , String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);		
	}
	
	@Test
	void eliminaTest() {
		String url = "http://localhost:" + port + "/comune/1"; 
		
		log.info("----------------cancellaTest" + url + "------DELETE");
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		log.info("----------------cancellaTest" + url + "------DELETE");
		r = trt.exchange(url, HttpMethod.DELETE, adminEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		log.info("----------------cancellaTest" + url + "------DELETE");
		r = trt.exchange(url, HttpMethod.DELETE,userEntity , String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
