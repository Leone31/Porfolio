package it.epicode.ees.test;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import it.epicode.ees.dto.FatturaDTO;
import it.epicode.ees.dto.FatturaModificaDTO;
import it.epicode.ees.impl.LoginRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * Classe di test per le chiamate del controller fattura
 * @author Marco Gambino
 * 
 */

@Slf4j
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class FatturaTest {

	@Autowired TestRestTemplate trt;
	@LocalServerPort int port;

	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("marco31");
		login.setPassword("marco31");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
		String jwt = trt.postForObject(url, loginRequest, String.class);
		log.info("---------" + jwt);
		return jwt;
	}

	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("billiballo");
		login.setPassword("marco31");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login); 
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}

	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		log.info(jwt);
		return header;
	}

	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}

	@Test
	void eliminaTest() {
		String url = "http://localhost:" + port + "/fattura/1"; 

		log.info("----------------cancellaTest" + url + "------DELETE");
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		log.info("----------------cancellaTest" + url + "------DELETE");
		r = trt.exchange(url, HttpMethod.DELETE, adminEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		log.info("----------------cancellaTest" + url + "------DELETE");
		r = trt.exchange(url, HttpMethod.DELETE,userEntity , String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);		
	}

	@Test
	void inserisciTest() {
		String url = "http://localhost:" + port + "/fattura"; 
		FatturaDTO fdto = new FatturaDTO();
		fdto.setNumeroFattura(3);
		fdto.setAnno(2022);
		fdto.setData(LocalDate.now());
		fdto.setImporto(BigDecimal.valueOf(2000.00));
		fdto.setStatoFatture(1);
		fdto.setId_cliente("123456789");

		HttpEntity<FatturaDTO> entity = new HttpEntity<FatturaDTO>(fdto);
		log.info("----------------inserisciTest" + url + "------POST");
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.POST, entity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<FatturaDTO> adminEntity = new HttpEntity<FatturaDTO>(fdto, getAdminHeader());
		log.info("----------------inserisciTest" + url + "------POST");
		r = trt.exchange(url, HttpMethod.POST, adminEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<FatturaDTO> userEntity = new HttpEntity<FatturaDTO>(fdto, getUserHeader());
		log.info("----------------inserisciTest" + url + "------POST");
		r = trt.exchange(url, HttpMethod.POST,userEntity , String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);		
	}

	@Test
	void modificaTest() {
		String url = "http://localhost:" + port + "/fattura/1"; 
		FatturaModificaDTO fdto = new FatturaModificaDTO();
		//fdto.setNumeroFattura(2);
		fdto.setAnno(2020);
		fdto.setData(LocalDate.now());
		fdto.setImporto(BigDecimal.valueOf(5231.00));
		fdto.setStatoFatture(1);
		fdto.setId_cliente("123456789");

		HttpEntity<FatturaModificaDTO> entity = new HttpEntity<FatturaModificaDTO>(fdto);
		log.info("----------------modificaTest" + url + "------PUT");
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.PUT, entity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<FatturaModificaDTO> adminEntity = new HttpEntity<FatturaModificaDTO>(fdto, getAdminHeader());
		log.info("----------------modificaTest" + url + "------PUT");
		r = trt.exchange(url, HttpMethod.PUT, adminEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<FatturaModificaDTO> userEntity = new HttpEntity<FatturaModificaDTO>(fdto, getUserHeader());
		log.info("----------------modificaTest" + url + "------PUT");
		r = trt.exchange(url, HttpMethod.PUT,userEntity , String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);		
	}


	@Test
	void cercaPerAnnoPaged() {
		String url = "http://localhost:" + port + "/fattura/anno/1988";
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = trt.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = trt.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	

	@Test
	void cercaPerStatoFatture() {
		String url = "http://localhost:" + port + "/fattura/stato/1";
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = trt.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = trt.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	

	@Test
	void cercaPerCliente() {
		String url = "http://localhost:" + port + "/fattura/piva/123456789";
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = trt.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = trt.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}


	@Test
	void cercaPerImportoRange() {
		String url = "http://localhost:" + port + "/fattura/range/900.0/1200.0";
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = trt.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = trt.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}


	@Test
	void cercaPerData() {
		String url = "http://localhost:" + port + "/fattura/perdata/2022-05-27"; //ATTENZIONE usare la data odierna
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.GET, HttpEntity.EMPTY,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> adminEntity = new HttpEntity<String>(getAdminHeader());
		r = trt.exchange(url, HttpMethod.GET, adminEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> userEntity = new HttpEntity<String>(getUserHeader());
		r = trt.exchange(url, HttpMethod.GET, userEntity,String.class);
		log.info("==================TEST GET" + url + "==================GET");
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}









}
