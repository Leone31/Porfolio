package it.epicode.ees;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S13FinalEpicEnergyServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
