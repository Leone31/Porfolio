package it.epicode.ees.model;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Classe che gestisce la persistenza su database della classe provincia
 * @author Marco Gambino
 * 
 */


@Data
@NoArgsConstructor
@Entity
public class Provincia {


	@Id
	private String sigla;
	private String nome;
	private String regione;

	@OneToMany(mappedBy = "provincia", cascade = CascadeType.REMOVE)
	@JsonIgnore
	private List<Comune> comuni = new ArrayList<>();


}
