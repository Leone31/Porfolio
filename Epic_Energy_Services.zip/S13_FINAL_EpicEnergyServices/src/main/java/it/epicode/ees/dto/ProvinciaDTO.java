package it.epicode.ees.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProvinciaDTO {


	private String sigla;
	private String nome;
	private String regione;

}
