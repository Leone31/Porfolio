package it.epicode.ees.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.epicode.ees.dto.ComuneDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.model.Comune;
import it.epicode.ees.model.Provincia;
import it.epicode.ees.repository.ComuneRepository;
import it.epicode.ees.repository.ProvinciaRepository;

/**
 * servizi DTO dei metodi inserisci, modifica, elimina
 * 
 * @author Marco Gambino 
 */

@Service
public class ComuneService {

	@Autowired ComuneRepository cr;
	@Autowired ProvinciaRepository pr;

	
	/**
	 * Metodo che inserisce un comune del db  
	*/
	public void inserisci(ComuneDTO request) throws AlreadyExistsException {
		Comune c = new Comune();
		Provincia p = pr.findById(request.getId_provincia()).get();
		BeanUtils.copyProperties(request, c);
		c.setProvincia(p);
		cr.save(c);
	}
	
	/**
	 * Metodo che modifica un comune nel db dando in input l'id  
	*/
	public Comune modifica(ComuneDTO request, Integer id) throws NotExistsException {
		if(!cr.existsById(id)) {
			throw new NotExistsException("Elemento gia presente");
		}
		Comune c = cr.findById(id).get();
		Provincia p = pr.findById(request.getId_provincia()).get();
		BeanUtils.copyProperties(request, c);
		c.setProvincia(p);
		return cr.save(c);
	}
	
	/**
	 * Metodo che elimina un comune dal db  
	*/
	public void elimina(Integer id) throws NotExistsException {
		if(!cr.existsById(id)) {
			throw new NotExistsException("Elemento NON presente");	
		}
		cr.deleteById(id);
	}
	
}
