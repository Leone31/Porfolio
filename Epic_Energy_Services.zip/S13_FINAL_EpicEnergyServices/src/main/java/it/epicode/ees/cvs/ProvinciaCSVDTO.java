package it.epicode.ees.cvs;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProvinciaCSVDTO {

	

	@JsonProperty("Sigla")
	private String sigla;
	@JsonProperty("Provincia")
	private String nome;
	@JsonProperty("Regione")
	private String regione;


}
