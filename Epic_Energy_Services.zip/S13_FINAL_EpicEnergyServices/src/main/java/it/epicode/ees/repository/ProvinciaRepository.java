package it.epicode.ees.repository;


import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.ees.model.Provincia;

/**
 * repository della classe provincia
 * @author Marco Gambino
 */

public interface ProvinciaRepository extends PagingAndSortingRepository<Provincia, String> {

	
	
}
