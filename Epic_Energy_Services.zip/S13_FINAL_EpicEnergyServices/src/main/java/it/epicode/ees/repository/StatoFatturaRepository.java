package it.epicode.ees.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.ees.model.StatoFattura;

/**
 * repository della classe stato fattura 
 * @author Marco Gambino
 */

public interface StatoFatturaRepository extends PagingAndSortingRepository<StatoFattura, Integer> {

	
	/**
	 * ricerca uno stato fattura per nome dando in input il nome dello stato 
	 * @return una lista di stati fattura
	 */
	
	public boolean existsByNome(String nome);
	
	
	
	
}
