package it.epicode.ees.dto;

import it.epicode.ees.model.TipoIndirizzo;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class IndirizzoDTO {

	private String via;
	private String civico;
	private String cap;
	private String localita;
	private TipoIndirizzo tipoIndirizzo;
	private Integer id_comune;
	
	
}
