package it.epicode.ees.services;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.ees.dto.ClienteDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.EmptyListException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.model.Cliente;
import it.epicode.ees.model.Indirizzo;
import it.epicode.ees.repository.ClienteRepository;
import it.epicode.ees.repository.IndirizzoRepository;

/**
 * servizi DTO dei metodi inserisci, modifica, elimina, mostra tutti, cerca per nome, cerca per data inserimento
 * cerca per data ultimo inserimento, cerca per fatturato annuale
 * 
 * @author Marco Gambino 
 */

@Service
public class ClienteService {

	@Autowired ClienteRepository cr;
	@Autowired IndirizzoRepository ir; 
	
	/**
	 * Metodo che inserisce un cliente del db  
	*/
	public void inserisci(ClienteDTO request) throws AlreadyExistsException {
		if(cr.existsById(request.getPIva())) {
			throw new AlreadyExistsException("Elemento gia presente");
		}
		Cliente c = new Cliente();
		BeanUtils.copyProperties(request, c);
		
		List<Indirizzo> newIndirizzo = new ArrayList<>();
		for(Integer id_Indirizzo : request.getIdIndirizzo()) {
			Indirizzo in = ir.findById(id_Indirizzo).get();
			newIndirizzo.add(in);
		}
		c.setIndirizzi(newIndirizzo);
		cr.save(c);
	}
	
	/**
	 * Metodo che modifica un cliente nel db dando in input la partita iva  
	*/
	public void modifica(ClienteDTO request, String pIva) throws NotExistsException {
		if(!cr.existsById(pIva)) {
			throw new NotExistsException("Elemento gia presente");
		}
		Cliente c = new Cliente();
		BeanUtils.copyProperties(request, c);
		
		List<Indirizzo> newIndirizzo = new ArrayList<>();
		for(Integer id_Indirizzo : request.getIdIndirizzo()) {
			Indirizzo in = ir.findById(id_Indirizzo).get();
			newIndirizzo.add(in);
		}
		c.setIndirizzi(newIndirizzo);
		cr.save(c);
	}
	
	/**
	 * Metodo che elimina un cliente dal db  
	*/
	public void elimina(String pIva) throws NotExistsException {
		if(!cr.existsById(pIva)) {
			throw new NotExistsException("Elemento NON presente");	
		}
		cr.deleteById(pIva);
	}
	
	/**
	 * Metodo che mostra tutti i clienti del db  
	*/
	public List<Cliente> mostraTutti() throws EmptyListException {
		if(cr.findAll().isEmpty()) {
			throw new EmptyListException ("Lista vuota!");
		}
		return (List<Cliente>) cr.findAll();
	}
	
	/**
	 * Metodo che mostra e impagina tutti i clienti del db  
	*/
	public Page mostraTuttiPaginati(Pageable page) {
		return cr.findAll(page);
	}
	
	/**
	 * Metodo che cerca i clienti dando in input il nome del contatto  
	*/
	public Page cercaPerNome(Pageable page, String nomeContatto) {
		return cr.findByNomeContattoContainingAllIgnoreCase(page, nomeContatto);
	}
	
	/**
	 * Metodo che cerca i clienti dando in input la data dell'inserimento 
	*/
	public List<Cliente> cercaPerDataInserimento(LocalDate dataInserimento) {
		return cr.findByDataInserimento(dataInserimento);
	}
	
	/**
	 * Metodo che cerca i clienti dando in input la data dell'ultimo contatto  
	*/
	public List<Cliente> cercaPerDataUltimoContatto(LocalDate dataUltimoContatto) {
		return cr.findByDataUltimoContatto(dataUltimoContatto);
	}
	
	/**
	 * Metodo che cerca i clienti dando in input il fatturato annuale 
	*/
	public List<Cliente> cercaPerFatturatoAnnuale(BigDecimal fatturatoAnnuale) {
		return cr.findByFatturatoAnnuale(fatturatoAnnuale);
	}
	
	
	
	
	
	
}
