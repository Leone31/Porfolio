package it.epicode.ees.cvs;



import com.fasterxml.jackson.annotation.JsonProperty;


import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
public class ComuneCSVDTO {

	

	@JsonProperty("Comune")
	private String nome;
	@JsonProperty("Provincia")
	private String provincia;
	@JsonProperty("CAP")
	private String cap;

}
