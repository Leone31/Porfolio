package it.epicode.ees.impl;

public enum ERole {
	
	ROLE_ADMIN,
	
	ROLE_USER;
}
