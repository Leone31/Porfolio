package it.epicode.ees.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import it.epicode.ees.model.Cliente;

/**
 * repository della classe cliente 
 * @author Marco Gambino
 */

public interface ClienteRepository extends PagingAndSortingRepository<Cliente, String> {

	
	/**
	 * ricerca di tutti i clienti nel db
	 * @return una lista di clienti
	 */
	public List<Cliente> findAll();
	
	/**
	 * ricerca e paginazione di una lista di clienti dando in input anche parte del nome ignorando il camel case
	 * @return una lista di clienti
	 */
	public Page<Cliente> findByNomeContattoContainingAllIgnoreCase(Pageable page, String nomeContatto);
	
	/**
	 * ricerca di clienti dando in input la data di inserimento
	 * @param dataInserimento
	 * @return una lista di clienti
	 */
	@Query("select c from Cliente c where c.dataInserimento =:dataInserimento")
	public List<Cliente> findByDataInserimento(@Param(value = "dataInserimento") LocalDate dataInserimento);
	
	/**
	 * ricerca di clienti dando in input la data di ultimo contatto
	 * @param dataUltimoContatto
	 * @return una lista di clienti
	 */
	@Query("select c from Cliente c where c.dataUltimoContatto =:dataUltimoContatto")
	public List<Cliente> findByDataUltimoContatto(@Param(value = "dataUltimoContatto") LocalDate dataUltimoContatto);
	
	/**
	 * ricerca di clienti dando in input la cifra del fatturato annuale
	 * @param fatturatoAnnuale
	 * @return una lista di clienti
	 */
	@Query("select c from Cliente c where c.fatturatoAnnuale =:fatturatoAnnuale")
	public List<Cliente> findByFatturatoAnnuale(@Param(value = "fatturatoAnnuale") BigDecimal fatturatoAnnuale);
	
	
}