package it.epicode.ees.config;

import java.io.File;
import java.util.List;
import java.util.Optional;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import it.epicode.ees.cvs.ComuneCSVDTO;
import it.epicode.ees.cvs.ProvinciaCSVDTO;
import it.epicode.ees.model.Comune;
import it.epicode.ees.model.Indirizzo;
import it.epicode.ees.model.Provincia;
import it.epicode.ees.model.TipoIndirizzo;
import it.epicode.ees.repository.ClienteRepository;
import it.epicode.ees.repository.ComuneRepository;
import it.epicode.ees.repository.FatturaRepository;
import it.epicode.ees.repository.IndirizzoRepository;
import it.epicode.ees.repository.ProvinciaRepository;
import it.epicode.ees.repository.StatoFatturaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@Component
@Data
@AllArgsConstructor
public class Runner implements ApplicationRunner {

	ComuneRepository cr;
	ProvinciaRepository pr;
	IndirizzoRepository ir;
	StatoFatturaRepository sfr;
	FatturaRepository fr;
	ClienteRepository clr;

	@Override
	public void run(ApplicationArguments args) throws Exception {



		String fileProvinciaCSV = "csv/province-italiane.csv";
		CsvSchema provinciaCSVSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader(); 
		CsvMapper mapper2 = new CsvMapper();
		File fileProvincia = new ClassPathResource(fileProvinciaCSV).getFile();
		MappingIterator<List<String>> valueReader2 = mapper2
				.reader(ProvinciaCSVDTO.class) 
				.with(provinciaCSVSchema)
				.readValues(fileProvincia);
		for(Object o2 : valueReader2.readAll()) {
			Provincia p = new Provincia();
			ProvinciaCSVDTO pcsv = (ProvinciaCSVDTO)o2;
			BeanUtils.copyProperties(o2, p);
			pr.save(p);
		}

		String fileComuneCSV = "csv/comuni-italiani.csv";
		CsvSchema comuneCSVSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader(); 
		CsvMapper mapper = new CsvMapper();
		File fileComune = new ClassPathResource(fileComuneCSV).getFile();
		MappingIterator<List<String>> valueReader = mapper
				.reader(ComuneCSVDTO.class) 
				.with(comuneCSVSchema)
				.readValues(fileComune);
		for(Object o : valueReader.readAll()) {
			Comune c = new Comune();
			ComuneCSVDTO ccsv = (ComuneCSVDTO)o;
			Optional<Provincia> p = pr.findById(ccsv.getProvincia());
			if(p.isPresent()) {
				BeanUtils.copyProperties(o, c);
				c.setProvincia(p.get());
			}
			if(c.getCap() != null) {
				cr.save(c);
			}
		}

		



	}






}
