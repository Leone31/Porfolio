package it.epicode.ees.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Classe che gestisce la persistenza su database della classe cliente
 * @author Marco Gambino
 * 
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {

	
	@Id
	private String pIva;
	
	private String ragioneSociale;
	
	private String email;
	private LocalDate dataInserimento;
	private LocalDate dataUltimoContatto;
	private BigDecimal fatturatoAnnuale;
	private String pec;
	private String telefono;
	private String emailContatto;
	private String nomeContatto;
	private String cognomeContatto;
	private String telefonoContatto;
	@Enumerated(EnumType.STRING)
	private TipoCliente tipoCliente;
	
	@ManyToMany
	@JoinTable(name = "indirizzi_clienti", joinColumns = @JoinColumn(name = "id_indirizzi"), inverseJoinColumns = @JoinColumn(name = "id_clienti"))
	@JsonIgnore
	private List<Indirizzo> indirizzi = new ArrayList<Indirizzo>();
	
	@OneToMany(mappedBy = "clienti", cascade = CascadeType.REMOVE)
	@JsonIgnore
	private List<Fattura> fatture = new ArrayList<Fattura>();
	
	
}
