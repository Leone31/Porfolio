package it.epicode.ees.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.ees.dto.ClienteDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.EmptyListException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.model.Cliente;
import it.epicode.ees.services.ClienteService;
import lombok.extern.slf4j.Slf4j;


/**
 * servizi rest relativi alla classe cliente
 * @author Marco Gambino
 * 
 */

@Slf4j
@RestController
@RequestMapping("/cliente")
public class ClienteController {

	@Autowired ClienteService cs;
	
	@Operation(summary = "Inserisce un cliente", description = "Inserisce un cliente nel db")
	@ApiResponse(responseCode = "200", description = "Inserito con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<String> inserisci(@RequestBody ClienteDTO request) throws AlreadyExistsException{
		log.info("*** INIZIO INSERIMENTO CLIENTE ***");
		cs.inserisci(request);
		return ResponseEntity.ok("Inserito correttamente!!!");
	}
	
	@Operation(summary = "Modifica un cliente", description = "Modifica un cliente nel db")
	@ApiResponse(responseCode = "200", description = "Eseguito con successo")
	@ApiResponse(responseCode = "500", description = "Errore!")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/{pIva}")
	public ResponseEntity<String> modifica( @PathVariable String pIva, @RequestBody ClienteDTO request) throws NotExistsException {
		log.info("*** INIZIO MODIFICA CLIENTE ***");
		cs.modifica(request, pIva);
		return ResponseEntity.ok("Modificato con successo!!!");
	}
	
	@Operation(summary = "Elimina un cliente", description = "Elimina un cliente nel db")
	@ApiResponse(responseCode = "200", description = "Eliminato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{pIva}")
	public ResponseEntity<String> elimina(@PathVariable String pIva) throws NotExistsException {
		log.info("*** INIZIO CANCELLAZIONE CLIENTE ***");
		cs.elimina(pIva);
		return ResponseEntity.ok("Eliminato con successo!!!");	
	}
	
	@Operation(summary = "Stampa tutti i clienti", description = "Stampa tutti i clienti del db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/trovatutti")
	public ResponseEntity<List<Cliente>> trovaTutti() throws EmptyListException {
		return ResponseEntity.ok(cs.mostraTutti());
	}
	
	@Operation(summary = "Stampa tutti i clienti paginati", description = "Stampa tutti i clienti paginati del db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/trovatuttipaginati")
	public ResponseEntity trovaTuttiPaginato(Pageable page) {
		return ResponseEntity.ok(cs.mostraTuttiPaginati(page));
	}
	
	@Operation(summary = "Cerca un cliente per nome", description = "Cerca un cliente per nome nel db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/cercapernome/{cercapernome}")
	public ResponseEntity cercaPerNome(@PathVariable String cercapernome, Pageable page) {
		return ResponseEntity.ok(cs.cercaPerNome(page, cercapernome));
	}
	
	@Operation(summary = "Cerca un cliente per data di inserimento", description = "Cerca un cliente per data di inserimento nel db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/data/{dataInserimento}")
	public ResponseEntity cercaPerDataInserimento(@PathVariable String dataInserimento) {
		LocalDate dataD = LocalDate.parse(dataInserimento, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		return ResponseEntity.ok(cs.cercaPerDataInserimento(dataD));
	}
	
	@Operation(summary = "Cerca un cliente per data ultimo contatto", description = "Cerca un cliente per data ultimo contatto nel db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/ultimocontatto/{ultimocontatto}")
	public ResponseEntity cercaPerDataUltimoContatto(@PathVariable String ultimocontatto) {
		LocalDate dataD = LocalDate.parse(ultimocontatto, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		return ResponseEntity.ok(cs.cercaPerDataUltimoContatto(dataD));
	}
	
	@Operation(summary = "Cerca un cliente per fatturato annuale", description = "Cerca un cliente per fatturato annuale nel db")
	@ApiResponse(responseCode = "200", description = "Eliminato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/fatturatoannuale/{fatturatoannuale}")
	public ResponseEntity cercaPerFatturatoAnnuale(@PathVariable BigDecimal fatturatoannuale) {
		return ResponseEntity.ok(cs.cercaPerFatturatoAnnuale(fatturatoannuale));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
