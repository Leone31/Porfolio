package it.epicode.ees.impl;

import java.util.HashSet;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RegistroRequest {

	private String nome;
	private String cognome;
	private String userName;
	private String password;
	private String email;
	private ERole ruolo;
	
	
	
	
	
}
