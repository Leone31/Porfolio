package it.epicode.ees.dto;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ComuneDTO {

	
	private String cap;
	private String nome;
	private String id_provincia;
	
}
