package it.epicode.ees.model;

public enum TipoCliente {

	PA, SAS, SPA, SRL
	
}