package it.epicode.ees.config;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.epicode.ees.impl.ERole;
import it.epicode.ees.impl.Role;
import it.epicode.ees.impl.User;
import it.epicode.ees.impl.UserRepository;




@Component
public class CreazioneUserRunner implements CommandLineRunner {

	@Autowired UserRepository ur;
	@Autowired PasswordEncoder pe;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		Role admin = new Role();
		admin.setRoleName(ERole.ROLE_ADMIN);
		
		User userAdmin = new User();
		Set<Role> ruoli = new HashSet<Role>();
		ruoli.add(admin);
		userAdmin.setRoles(ruoli);
		userAdmin.setUsername("marco31");
		userAdmin.setPassword(pe.encode("marco31"));
		userAdmin.setNome("Marco");
		userAdmin.setCognome("Gambino");
		userAdmin.setEmail("marcog@gmail.com");
		
		ur.save(userAdmin);
		
		Role admin2 = new Role();
		admin2.setRoleName(ERole.ROLE_USER);
		
		User userAdmin2 = new User();
		Set<Role> ruoli2 = new HashSet<Role>();
		ruoli2.add(admin2);
		userAdmin2.setRoles(ruoli2);
		userAdmin2.setUsername("billiballo");
		userAdmin2.setPassword(pe.encode("marco31"));
		userAdmin2.setNome("Marco");
		userAdmin2.setCognome("Gambino");
		userAdmin2.setEmail("marcog@gmail.com");
		
		ur.save(userAdmin2);
		
		
		
		
		
	}

}
