package it.epicode.ees.services;



import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import it.epicode.ees.dto.StatoFatturaDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.model.StatoFattura;
import it.epicode.ees.repository.StatoFatturaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * servizi DTO dei metodi inserisci, modifica, elimina
 * 
 * @author Marco Gambino 
 */

@Service
@Data
@AllArgsConstructor
public class StatoFatturaService {

	StatoFatturaRepository sfr;
	
	/**
	 * Metodo che inserisce uno stato fattura nel db  
	*/
	public void inserisci(StatoFatturaDTO request) throws AlreadyExistsException {
		if(sfr.existsByNome(request.getNome())) {
			throw new AlreadyExistsException("Elemento gia presente");
		}
		StatoFattura sf = new StatoFattura();
		BeanUtils.copyProperties(request, sf);
		sfr.save(sf);
	}
	
	/**
	 * Metodo che modifica uno stato fattura nel db dando in input l'id  
	*/
	public StatoFattura modifica(StatoFatturaDTO request, Integer id) throws NotExistsException {
		if(!sfr.existsById(id)) {
			throw new NotExistsException("Elemento NON presente");
		}
		StatoFattura sf = sfr.findById(id).get();
		BeanUtils.copyProperties(request, sf);
		return sfr.save(sf);
	}
	
	/**
	 * Metodo che elimina uno stato fattura dal db  
	*/
	public void elimina(Integer id) throws NotExistsException {
		if(!sfr.existsById(id)) {
			throw new NotExistsException("Elemento NON presente");	
		}
		sfr.deleteById(id);
	}
	
}
