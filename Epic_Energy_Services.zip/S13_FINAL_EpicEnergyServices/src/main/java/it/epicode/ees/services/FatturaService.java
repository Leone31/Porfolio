package it.epicode.ees.services;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import it.epicode.ees.dto.FatturaDTO;
import it.epicode.ees.dto.FatturaModificaDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.model.Cliente;
import it.epicode.ees.model.Fattura;
import it.epicode.ees.model.StatoFattura;
import it.epicode.ees.repository.ClienteRepository;
import it.epicode.ees.repository.FatturaRepository;
import it.epicode.ees.repository.StatoFatturaRepository;

/**
 * servizi DTO dei metodi inserisci, modifica, elimina, cerca per data, cerca per anno, cerca per cliente, 
 * cerca per range di importi e cerca per stato fattura  
 * 
 * @author Marco Gambino 
 */

@Service
public class FatturaService {

	@Autowired FatturaRepository fr;
	@Autowired ClienteRepository cr;
	@Autowired StatoFatturaRepository sfr;
	
	public void inserisci(FatturaDTO request) throws AlreadyExistsException {
		if(fr.existsById(request.getNumeroFattura())) {
			throw new AlreadyExistsException("Elemento gia presente");
		}
		Fattura f = new Fattura();
		Cliente c = cr.findById(request.getId_cliente()).get();
		StatoFattura sf = sfr.findById(request.getStatoFatture()).get();
		BeanUtils.copyProperties(request, f);
		f.setClienti(c);
		f.setStatoFatture(sf);
		fr.save(f);
	}
	
	public void modifica(FatturaModificaDTO request, Integer numero) throws NotExistsException {
		if(!fr.existsById(numero)) {
			throw new NotExistsException("Elemento NON presente");
		}
		Fattura f = fr.findById(numero).get();
		Cliente c = cr.findById(request.getId_cliente()).get();
		StatoFattura sf = sfr.findById(request.getStatoFatture()).get();
		BeanUtils.copyProperties(request, f);
		f.setClienti(c);
		f.setStatoFatture(sf);
		fr.save(f);
	}
	
	public void elimina(Integer numeroF) throws NotExistsException {
		if(!fr.existsById(numeroF)) {
			throw new NotExistsException("Elemento NON presente");	
		}
		fr.deleteById(numeroF);
	}
	
	public List<Fattura> cercaPerData(LocalDate data) {
		return fr.findByData(data);
	}
	
	public List<Fattura> cercaPerAnno(Integer anno) {
		return fr.findByAnno(anno);
	}
	
	public List<Fattura> cercaPerCliente(String pIva) {
		return fr.filterByClienti(pIva); 
	}
	
	public List<Fattura> cercaPerRangeDiImporti(BigDecimal importoMin, BigDecimal importoMax) {
		return fr.findByImporto(importoMin, importoMax);
	}
	
	public List<Fattura> cercaPerStatoFatture(String stato) {
		return fr.filterByStatoFatture(stato);
	}
	
	
}
