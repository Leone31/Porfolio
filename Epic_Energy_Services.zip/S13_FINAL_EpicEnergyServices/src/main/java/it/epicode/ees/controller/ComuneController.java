package it.epicode.ees.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.ees.dto.ComuneDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.services.ComuneService;
import lombok.extern.slf4j.Slf4j;


/**
 * servizi rest relativi alla classe comune
 * @author Marco Gambino
 * 
 */

@Slf4j
@RestController
@RequestMapping("/comune")
public class ComuneController {

	@Autowired ComuneService cs;
	
	@Operation(summary = "Inserisce un comune", description = "Inserisce un comune nel db")
	@ApiResponse(responseCode = "200", description = "Inserito con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<String> inserisci(@RequestBody ComuneDTO request) throws AlreadyExistsException{
		log.info("*** INIZIO INSERIMENTO COMUNE ***");
		cs.inserisci(request);
		return ResponseEntity.ok("Inserito correttamente!!!");
	}
	
	@Operation(summary = "Modifica un comune", description = "Modifica un comune nel db")
	@ApiResponse(responseCode = "200", description = "Eseguito con successo")
	@ApiResponse(responseCode = "500", description = "Errore!")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<String> modifica( @PathVariable Integer id, @RequestBody ComuneDTO request) throws NotExistsException {
		log.info("*** INIZIO MODIFICA COMUNE ***");
		cs.modifica(request, id);
		return ResponseEntity.ok("Modificato con successo!!!");
	}
	
	@Operation(summary = "Elimina un comune", description = "Elimina un comune nel db")
	@ApiResponse(responseCode = "200", description = "Eliminato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<String> elimina(@PathVariable ("id") Integer id) throws NotExistsException {
		log.info("*** INIZIO CANCELLAZIONE COMUNE ***");
		cs.elimina(id);
		return ResponseEntity.ok("Eliminato con successo!!!");	
	}
	
	
	
	
	
	
}
