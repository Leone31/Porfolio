package it.epicode.ees.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.ees.dto.IndirizzoDTO;

import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.model.Comune;
import it.epicode.ees.model.Indirizzo;
import it.epicode.ees.repository.ComuneRepository;
import it.epicode.ees.repository.IndirizzoRepository;

/**
 * servizi DTO dei metodi inserisci, modifica, elimina
 * 
 * @author Marco Gambino 
 */		

@Service
public class IndirizzoService {

	@Autowired IndirizzoRepository ir;
	@Autowired ComuneRepository cr;
	
	public void inserisci(IndirizzoDTO request) {
		Indirizzo in = new Indirizzo();
		Comune c = cr.findById(request.getId_comune()).get();
		BeanUtils.copyProperties(request, in);
		in.setComuni(c);
		ir.save(in);
	}
	
	public void modifica(IndirizzoDTO request, Integer id) throws NotExistsException {
		if(!ir.existsById(id)) {
			throw new NotExistsException("Elemento Non presente");
		}
		Indirizzo in = ir.findById(id).get();
		Comune c = cr.findById(request.getId_comune()).get();
		BeanUtils.copyProperties(request, in);
		in.setComuni(c);
		ir.save(in);
	}
	
	public void elimina(Integer id) throws NotExistsException {
		if(!ir.existsById(id)) {
			throw new NotExistsException("Elemento NON presente");	
		}
		ir.deleteById(id);
	}
	
	
	
}
