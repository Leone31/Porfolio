package it.epicode.ees.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.ees.dto.IndirizzoDTO;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.services.IndirizzoService;


/**
 * servizi rest relativi alla classe indirizzo
 * @author Marco Gambino
 * 
 */

@RestController
@RequestMapping("/indirizzo")
public class IndirizzoController {

	@Autowired IndirizzoService is;
	
	@Operation(summary = "Inserisce un indirizzo", description = "Inserisce un indirizzo nel db")
	@ApiResponse(responseCode = "200", description = "Inserito con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<String> inserisci(@RequestBody IndirizzoDTO request) {
		is.inserisci(request);
		return ResponseEntity.ok("Inserito correttamente!!!");
	}
	
	@Operation(summary = "Modifica una provincia", description = "Modifica una provincia nel db")
	@ApiResponse(responseCode = "200", description = "Eseguito con successo")
	@ApiResponse(responseCode = "500", description = "Errore!")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<String> modifica( @PathVariable Integer id, @RequestBody IndirizzoDTO request) throws NotExistsException {
		is.modifica(request, id);
		return ResponseEntity.ok("Modificato con successo!!!");
	}
	
	@Operation(summary = "Elimina un indirizzo", description = "Elimina un indirizzo nel db")
	@ApiResponse(responseCode = "200", description = "Eliminato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<String> elimina(@PathVariable Integer id) throws NotExistsException {
		is.elimina(id);
		return ResponseEntity.ok("Eliminato con successo!!!");	
	}
	
	
	
	
	
	
}
