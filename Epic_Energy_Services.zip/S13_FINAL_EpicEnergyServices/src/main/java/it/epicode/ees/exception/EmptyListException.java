package it.epicode.ees.exception;

public class EmptyListException extends Exception {

	public EmptyListException(String message) {
		super(message);
		
	}
}
