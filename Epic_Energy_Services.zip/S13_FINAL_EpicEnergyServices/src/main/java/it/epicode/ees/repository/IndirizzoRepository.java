package it.epicode.ees.repository;


import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.ees.model.Indirizzo;

/**
 * repository della classe indirizzo 
 * @author Marco Gambino
 */


public interface IndirizzoRepository extends PagingAndSortingRepository<Indirizzo, Integer> {

	
	
}
