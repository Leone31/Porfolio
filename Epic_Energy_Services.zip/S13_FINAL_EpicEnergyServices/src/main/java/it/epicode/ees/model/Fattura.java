package it.epicode.ees.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Classe che gestisce la persistenza su database della classe fattura
 * @author Marco Gambino
 * 
 */


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Fattura {


	@Id
	private Integer numeroFattura;
	private Integer anno;
	private LocalDate data;
	private BigDecimal importo;

	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JoinColumn(name = "stato_fatture")
	@JsonIgnore
	private StatoFattura statoFatture;

	@ManyToOne
	@JoinColumn
	@JsonIgnore
	private Cliente clienti;
	
}
