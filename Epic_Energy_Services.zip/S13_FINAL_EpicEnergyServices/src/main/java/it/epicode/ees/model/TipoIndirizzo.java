package it.epicode.ees.model;

public enum TipoIndirizzo {

	SEDE_LEGALE,
	SEDE_OPERATIVA;
	
}
