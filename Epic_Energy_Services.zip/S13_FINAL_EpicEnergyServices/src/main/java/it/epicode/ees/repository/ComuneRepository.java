package it.epicode.ees.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.ees.model.Comune;

/**
 * repository della classe comune 
 * @author Marco Gambino
 */

public interface ComuneRepository extends PagingAndSortingRepository<Comune, Integer> {
	
	/**
	 * condizione di esistenza di un nome nella lista comune dando in input il nome del comune
	 * @return un boolean 
	 */
	
	public boolean existsByNome(String nome);

}
