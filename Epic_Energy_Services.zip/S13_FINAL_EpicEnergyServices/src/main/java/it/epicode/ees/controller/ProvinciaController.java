package it.epicode.ees.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.ees.dto.ProvinciaDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.services.ProvinciaService;


/**
 * servizi rest relativi alla classe provincia
 * @author Marco Gambino
 * 
 */

@RestController
@RequestMapping("/provincia")
public class ProvinciaController {

	@Autowired ProvinciaService ps;
	
	@Operation(summary = "Inserisce una provincia", description = "Inserisce una provincia nel db")
	@ApiResponse(responseCode = "200", description = "Inserito con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<String> inserisci(@RequestBody ProvinciaDTO request) throws AlreadyExistsException{
		ps.inserisci(request);
		return ResponseEntity.ok("Inserito correttamente!!!");
	}
	
	@Operation(summary = "Modifica una provincia", description = "Modifica una provincia nel db")
	@ApiResponse(responseCode = "200", description = "Eseguito con successo")
	@ApiResponse(responseCode = "500", description = "Errore!")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/{sigla}")
	public ResponseEntity<String> modifica( @PathVariable String sigla, @RequestBody ProvinciaDTO request) throws NotExistsException {
		ps.modifica(request, sigla);
		return ResponseEntity.ok("Modificato con successo!!!");
	}
	
	@Operation(summary = "Elimina una provincia", description = "Elimina una provincia nel db")
	@ApiResponse(responseCode = "200", description = "Eliminato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{sigla}")
	public ResponseEntity<String> elimina(@PathVariable String sigla) throws NotExistsException {
		ps.elimina(sigla);
		return ResponseEntity.ok("Eliminato con successo!!!");	
	}
	
	
	
	
	
	
}
