package it.epicode.ees.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Classe che gestisce la persistenza su database della classe indirizzo
 * @author Marco Gambino
 * 
 */


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Indirizzo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private String via;
	private String civico;
	private String cap;
	private String localita;
	@Enumerated(EnumType.STRING)
	private TipoIndirizzo tipoIndirizzo;

	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JoinColumn
	@JsonIgnore
	private Comune comuni;
	
	@ManyToMany(mappedBy = "indirizzi")
	@JsonIgnore
	private List<Cliente> clienti = new ArrayList<Cliente>();
}
