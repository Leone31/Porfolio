package it.epicode.ees.repository;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import it.epicode.ees.model.Cliente;
import it.epicode.ees.model.Fattura;

/**
 * repository della classe fattura 
 * @author Marco Gambino
 */


public interface FatturaRepository extends PagingAndSortingRepository<Fattura, Integer> {

	/**
	 * ricerca di una fattura per data emissione dando in input la data
	 * usando una query jpql
	 * 
	 * @param data
	 * @return una lista di fatture 
	 * 	 
	*/
	@Query("select f from Fattura f where f.data =:data")
	public List<Fattura> findByData(@Param(value = "data") LocalDate data);
	
	/**
	 * ricerca di una fattura per anno di riferimento dando in input l'anno
	 * usando una query jpql
	 * 
	 * @param anno
	 * @return una lista di fatture 
	 * 	 
	*/
	@Query("select f from Fattura f where f.anno =:anno")
	public List<Fattura> findByAnno(@Param(value = "anno")  Integer anno);
	
	/**
	 * ricerca di una fattura per nome cliente dando in input la partita iva
	 * usando una query jpql
	 * 
	 * @param pIva
	 * @return una lista di fatture dello stesso cliente 
	 * 	 
	*/
	@Query("select f from Fattura f join f.clienti c where c.pIva =:pIva")
	public List<Fattura> filterByClienti(@Param(value = "pIva") String pIva);
	
	/**
	 * ricerca di una fattura per range di importi dando in input un range di valori
	 * usando una query jpql
	 * 
	 * @param importoMin, importoMax
	 * @return una lista di fatture 
	 * 	 
	*/
	@Query("select f from Fattura f where f.importo between :importoMin and :importoMax")
	public List<Fattura> findByImporto(@Param(value = "importoMin") BigDecimal importoMin, @Param(value = "importoMax") BigDecimal importoMax);
	
	/**
	 * ricerca di una fattura per stato di fatture dando in input il nome dello stato
	 * usando una query jpql
	 * 
	 * @param nome
	 * @return una lista di fatture 
	 * 	 
	*/
	@Query("select f from Fattura f join f.statoFatture s where s.nome =:nome")
	public List<Fattura> filterByStatoFatture(@Param(value = "nome") String nome);

	
	
}
