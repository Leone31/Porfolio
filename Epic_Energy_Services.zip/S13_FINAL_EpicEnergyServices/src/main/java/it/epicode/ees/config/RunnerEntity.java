package it.epicode.ees.config;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import it.epicode.ees.model.Cliente;
import it.epicode.ees.model.Fattura;
import it.epicode.ees.model.Indirizzo;
import it.epicode.ees.model.StatoFattura;
import it.epicode.ees.model.TipoCliente;
import it.epicode.ees.model.TipoIndirizzo;
import it.epicode.ees.repository.ClienteRepository;
import it.epicode.ees.repository.ComuneRepository;
import it.epicode.ees.repository.FatturaRepository;
import it.epicode.ees.repository.IndirizzoRepository;
import it.epicode.ees.repository.ProvinciaRepository;
import it.epicode.ees.repository.StatoFatturaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@Component
@Data
@AllArgsConstructor
public class RunnerEntity implements ApplicationRunner {

	ComuneRepository cr;
	ProvinciaRepository pr;
	IndirizzoRepository ir;
	StatoFatturaRepository sfr;
	FatturaRepository fr;
	ClienteRepository clr;


	@Override
	public void run(ApplicationArguments args) throws Exception {

		StatoFattura sf = new StatoFattura();
		sf.setNome("Pagato");
		sfr.save(sf);
	
		Indirizzo in = new Indirizzo();
		in.setVia("Via dalle palle");
		in.setCivico("69");
		in.setCap("90100");
		in.setLocalita("Mondello");
		in.setTipoIndirizzo(TipoIndirizzo.SEDE_LEGALE);
		ir.save(in);
		
		Cliente c = new Cliente();
		List<Indirizzo> ind = new ArrayList<Indirizzo>();
		List<Fattura> fat = new ArrayList<Fattura>();
		ind.add(in);
		c.setPIva("123456789");
		c.setRagioneSociale("Il Buco Nero");
		c.setEmail("ilbuconero@universo.com");
		c.setDataInserimento(LocalDate.of(2020, 8, 16));
		c.setDataUltimoContatto(LocalDate.of(2022, 8, 16));
		c.setFatturatoAnnuale(BigDecimal.valueOf(2000.0));
		c.setPec("ilbuconero@pec.it");
		c.setTelefono("09123232323");
		c.setEmailContatto("biancaneri@hotuniversal.com");
		c.setNomeContatto("Bianca");
		c.setCognomeContatto("Neri");
		c.setTelefonoContatto("3283456789");
		c.setTipoCliente(TipoCliente.SRL);
		c.setFatture(fat);
		c.setIndirizzi(ind);
		clr.save(c);
		
		Fattura f = new Fattura();
		f.setNumeroFattura(1);
		f.setAnno(1988);
		f.setData(LocalDate.now());
		f.setImporto(BigDecimal.valueOf(1000.00));
		f.setClienti(c);
		f.setStatoFatture(sf);
		fr.save(f);
		
	}


}
