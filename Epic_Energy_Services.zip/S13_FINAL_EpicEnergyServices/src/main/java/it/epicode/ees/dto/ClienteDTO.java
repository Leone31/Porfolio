package it.epicode.ees.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import it.epicode.ees.model.TipoCliente;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ClienteDTO {

	final static String DATE_PATTERN = "dd/MM/yyyy";
	
	private String pIva;
	private String ragioneSociale;
	private String email;
	@Schema(example = "16/08/1988", type = "string")
	@JsonFormat(pattern = DATE_PATTERN)
	private LocalDate dataInserimento;
	@Schema(example = "16/08/1988", type = "string")
	@JsonFormat(pattern = DATE_PATTERN)	
	private LocalDate dataUltimoContatto;
	private BigDecimal fatturatoAnnuale;
	private String pec;
	private String telefono;
	private String emailContatto;
	private String nomeContatto;
	private String cognomeContatto;
	private String telefonoContatto;
	@Enumerated(EnumType.STRING)
	private TipoCliente tipoCliente;
	private List<Integer> idIndirizzo;
	
	
}
