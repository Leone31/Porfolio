package it.epicode.ees.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class StatoFatturaDTO {

	
	private String nome;
	
}
