package it.epicode.ees.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.epicode.ees.dto.ProvinciaDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.model.Provincia;
import it.epicode.ees.repository.ProvinciaRepository;

/**
 * servizi DTO dei metodi inserisci, modifica, elimina
 * 
 * @author Marco Gambino 
 */		
		
@Service
public class ProvinciaService {

	@Autowired ProvinciaRepository pr;
	
	public void inserisci(ProvinciaDTO request) throws AlreadyExistsException {
		Provincia p = new Provincia();
		BeanUtils.copyProperties(request, p);
		pr.save(p);
	}
	
	public void modifica(ProvinciaDTO request, String sigla) throws NotExistsException {
		if(!pr.existsById(sigla)) {
			throw new NotExistsException("Elemento gia presente");
		}
		Provincia p = new Provincia();
		BeanUtils.copyProperties(request, p);
		pr.save(p);
	}
	
	public void elimina(String sigla) throws NotExistsException {
		if(!pr.existsById(sigla)) {
			throw new NotExistsException("Elemento NON presente");	
		}
		pr.deleteById(sigla);
	}
	
}
