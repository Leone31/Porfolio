package it.epicode.ees.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.ees.dto.FatturaDTO;
import it.epicode.ees.dto.FatturaModificaDTO;
import it.epicode.ees.exception.AlreadyExistsException;
import it.epicode.ees.exception.EmptyListException;
import it.epicode.ees.exception.NotExistsException;
import it.epicode.ees.model.Cliente;
import it.epicode.ees.services.FatturaService;


/**
 * servizi rest relativi alla classe fattura
 * @author Marco Gambino
 * 
 */

@RestController
@RequestMapping("/fattura")
public class FatturaController {

	@Autowired FatturaService fs;
	
	@Operation(summary = "Inserisce una fattura", description = "Inserisce una fattura nel db")
	@ApiResponse(responseCode = "200", description = "Inserito con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<String> inserisci(@RequestBody FatturaDTO request) throws AlreadyExistsException{
		fs.inserisci(request);
		return ResponseEntity.ok("Inserito correttamente!!!");
	}
	
	@Operation(summary = "Modifica una fattura", description = "Modifica una fattura nel db")
	@ApiResponse(responseCode = "200", description = "Eseguito con successo")
	@ApiResponse(responseCode = "500", description = "Errore!")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/{numero}")
	public ResponseEntity<String> modifica( @PathVariable Integer numero, @RequestBody FatturaModificaDTO request) throws NotExistsException {
		fs.modifica(request, numero);
		return ResponseEntity.ok("Modificato con successo!!!");
	}
	
	@Operation(summary = "Elimina una fattura", description = "Elimina una fattura nel db")
	@ApiResponse(responseCode = "200", description = "Eliminato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{numero}")
	public ResponseEntity<String> elimina(@PathVariable Integer numero) throws NotExistsException {
		fs.elimina(numero);
		return ResponseEntity.ok("Eliminato con successo!!!");	
	}
	
	@Operation(summary = "Cerca una fattura per data", description = "Cerca una fattura per data nel db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/perdata/{data}")
	public ResponseEntity cercaPerData(@PathVariable String data) {
		LocalDate dataD = LocalDate.parse(data, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		return ResponseEntity.ok(fs.cercaPerData(dataD));
	}
	
	@Operation(summary = "Cerca una fattura per anno", description = "Cerca una fattura per anno nel db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/anno/{anno}")
	public ResponseEntity cercaPerAnno(@PathVariable Integer anno, Pageable page) throws EmptyListException {
		return ResponseEntity.ok(fs.cercaPerAnno(anno));
	}
	
	@Operation(summary = "Cerca una fattura per cliente", description = "Cerca una fattura per cliente nel db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/piva/{pIva}")
	public ResponseEntity cercaPerCliente(@PathVariable String pIva) {
		return ResponseEntity.ok(fs.cercaPerCliente(pIva));
	}
	
	@Operation(summary = "Cerca una fattura per range di importi", description = "Cerca una fattura per range di importi nel db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/range/{importoMin}/{importoMax}")
	public ResponseEntity cercaPerRangeDiImporti(@PathVariable BigDecimal importoMin, BigDecimal importoMax) {
		return ResponseEntity.ok(fs.cercaPerRangeDiImporti(importoMin, importoMax));
	}
	
	@Operation(summary = "Cerca una fattura per stato fatture", description = "Cerca una fattura per stato fatture nel db")
	@ApiResponse(responseCode = "200", description = "Effettuato con successo nel db")
	@ApiResponse(responseCode = "500", description = "Errore nella cancellazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/stato/{stato}")
	public ResponseEntity cercaPerStatoFatture(@PathVariable String stato) {
		return ResponseEntity.ok(fs.cercaPerStatoFatture(stato));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
