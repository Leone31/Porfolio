package it.epicode.ees.exception;

public class NotExistsException extends Exception {
	
	public NotExistsException(String message) {
		super(message);
		
	}

}
